package Controle;

import Modelo.model_produto;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import utilitarios.Conecta_Banco;

public class control_produto {

    // Cria uma nova instância das classes Conecta_Banco e model_produto.
    Conecta_Banco connProduto = new Conecta_Banco();
    model_produto mod = new model_produto();

    
    public void inserir_produto(model_produto mod) {
        
        //Inicia uma conexão com o banco de dados 
        connProduto.conexao();
        connProduto.executaSQL("USE empresa;");
        

        try {
            
            // Realiza a inserção no banco de dados 
            PreparedStatement pst = connProduto.conn.prepareStatement("insert into produtos "
                    + "(nome, valor, quantidade) values (?,?,?)");
            
            // Seta os valores para cada váriavel
            pst.setString(1, mod.getNome());
            pst.setDouble(2, mod.getValor());
            pst.setInt(3, mod.getQuant());
            // Executa a inclusão dos valores setados acima
            pst.execute();
            
            //Mostra a mensagem na tela caso o produto foi salvo com sucesso
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!", "ATENÇÃO:", 0);
            
        } catch (SQLException ex) {
            
            // Mostra a mensagem na tela se ocorreu algum erro na tentativa de salvar o produto.
            JOptionPane.showMessageDialog(null, "Erro ao executar operação.\n Erro:" + ex, "ERRO", 0);
        }
        
        // Encerra a conexão com o banco de dados
        connProduto.desconecta();

    }

    
    public void Excluir_Produto(model_produto mod) {
        
         //Inicia uma conexão com o banco de dados 
        connProduto.conexao();
        connProduto.executaSQL("USE empresa;");
        
        
        try {
            
            // Realiza a exclusão no banco de dados 
            PreparedStatement pst = connProduto.conn.prepareStatement("delete from "
                    + "produtos where id=?");
            
            // Seta o código que será executado
            pst.setInt(1, mod.getCodigo());
            // Executa a exclusão setado acima
            pst.execute();
            
            //Mostra a mensagem na tela caso o produto foi excluído com sucesso
            JOptionPane.showMessageDialog(null, "Produto excluído com "
                    + "sucesso!", "ATENÇÃO", 0);
            
            
        } catch (SQLException ex) {
            
            // Mostra a mensagem na tela se ocorreu algum erro na tentativa de salvar o produto.
            JOptionPane.showMessageDialog(null, "Erro ao excluir "
                    + "produto!\n ERRO:" + ex, "ATENÇÃO", 0);
        }
        
         // Encerra a conexão com o banco de dados
        connProduto.desconecta();
    }

    
    public void Alterar_Produto(model_produto mod) {
        
        //Inicia uma conexão com o banco de dados
        connProduto.conexao();
        connProduto.executaSQL("USE empresa;");
        
        try {
            
            // Realiza a exclusão no banco de dados 
            PreparedStatement pst = connProduto.conn.prepareStatement("update produtos set "
                    + "nome = ?, valor = ?, quantidade = ? where id=?");
            
            // Seta as variáveis que serão alteradas
            pst.setString(1, mod.getNome());
            pst.setDouble(2, mod.getValor());
            pst.setInt(3, mod.getQuant());
            pst.setInt(4, mod.getCodigo());
            // Executa a alteração setada acima
            pst.execute();
            
            //Mostra a mensagem na tela caso o produto foi excluído com sucesso
            JOptionPane.showMessageDialog(null, "Produto alterado com sucesso!", "ATENÇÃO", 0);
            
        } catch (SQLException ex) {
            
            // Mostra a mensagem na tela se ocorreu algum erro na tentativa de salvar a alteração do produto.
            JOptionPane.showMessageDialog(null, "Erro ao alterar "
                    + "produto!\n ERRO:" + ex, "ATENÇÃO", 0);
        }
        
        // Encerra a conexão com o banco de dados
        connProduto.desconecta();
    }

}
