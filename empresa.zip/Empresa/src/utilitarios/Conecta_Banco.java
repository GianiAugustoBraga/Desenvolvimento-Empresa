package utilitarios;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class Conecta_Banco {

    public Statement stm;
    public ResultSet rs;
    private String driver = "com.mysql.jdbc.Driver";
    private String caminho = "jdbc:mysql://127.0.0.1:3306";
    private String usuario = "root";
    private String senha = "";
    public Connection conn;

    public void conexao() {
        try {

            // Estabelece uma conexão com o banco de dados
            System.setProperty("com.mysql.jdbc.Drivers", driver);
            conn = DriverManager.getConnection(caminho, usuario, senha);
            // JOptionPane.showMessageDialog(null,"Conexão realizada com sucesso no mysql","ATENÇÃO",0);

        } catch (SQLException ex) {

            // Caso encontrar algum erro vai mostrar a mensagem que a conexão não foi realizada 
            JOptionPane.showMessageDialog(null, "Conexão não foi realizada com mysql!\n ERRO:" + ex.getMessage(), "ERRO", 0);
        }
    }

    
    public void executaSQL(String sql) {

        try {
            
            stm = conn.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            rs = stm.executeQuery(sql);
            //JOptionPane.showMessageDialog(null, "Execução SQL com Sucesso!", "ATENÇÃO", 0);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Não foi possível executar SQL!\n ERRO:" + ex.getMessage(), "ERRO", 0);
        }
    }

    public void desconecta() {
        try {
            conn.close();

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(null, "ERRO! Erro ao fechar a "
                    + "conexão!\n ERRO:" + ex.getMessage(), "ERRO:", 0);
        }
    }
}
